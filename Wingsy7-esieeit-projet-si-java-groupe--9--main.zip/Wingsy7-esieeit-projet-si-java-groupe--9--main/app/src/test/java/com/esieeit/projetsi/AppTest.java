package com.esieeit.projetsi;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {
    @Test
    void sanity_check() {
        assertTrue(true, "Le projet est bien initialisé");
    }
}
