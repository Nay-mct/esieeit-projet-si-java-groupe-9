package com.esieeit.projetsi;

public class App {
    public static void main(String[] args) {
        System.out.println("Projet SI Java - init OK");
    }
}
